import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { CelestialBackdrop } from '@/components/ui/CelestialBackdrop'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import LandingPage from '@/pages/LandingPage'

/**
 * Route table. Only the Landing Page is built for real right now —
 * everything else is scaffolded as a route so the app is fully
 * navigable while each remaining page is built out, one at a time.
 * Replace each placeholder import as its page is delivered.
 */
function ComingSoon({ title }: { title: string }) {
  return (
    <div className="relative z-10 min-h-[70vh] flex flex-col items-center justify-center text-center px-6 pt-32">
      <h1 className="font-display text-3xl font-semibold text-on-surface mb-3">{title}</h1>
      <p className="text-on-surface-variant max-w-md">
        This page hasn't been built yet — it's next up in the SkillSync build queue.
      </p>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <CelestialBackdrop />
      <Navbar />
      <main className="relative z-10">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<ComingSoon title="Log in" />} />
          <Route path="/register" element={<ComingSoon title="Create your account" />} />
          <Route path="/forgot-password" element={<ComingSoon title="Reset your password" />} />
          <Route path="/dashboard" element={<ComingSoon title="Dashboard" />} />
          <Route path="/profile" element={<ComingSoon title="Profile" />} />
          <Route path="/profile/edit" element={<ComingSoon title="Edit profile" />} />
          <Route path="/explore" element={<ComingSoon title="Skill explorer" />} />
          <Route path="/skills/:id" element={<ComingSoon title="Skill details" />} />
          <Route path="/matches" element={<ComingSoon title="Matches" />} />
          <Route path="/chat" element={<ComingSoon title="Chat" />} />
          <Route path="/sessions/new" element={<ComingSoon title="Schedule a session" />} />
          <Route path="/calendar" element={<ComingSoon title="Calendar" />} />
          <Route path="/reviews" element={<ComingSoon title="Reviews" />} />
          <Route path="/achievements" element={<ComingSoon title="Achievements" />} />
          <Route path="/notifications" element={<ComingSoon title="Notifications" />} />
          <Route path="/settings" element={<ComingSoon title="Settings" />} />
          <Route path="/admin" element={<ComingSoon title="Admin dashboard" />} />
          <Route path="*" element={<ComingSoon title="404 — Lost in space" />} />
        </Routes>
      </main>
      <Footer />
    </BrowserRouter>
  )
}
