import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { CelestialBackdrop } from '@/components/ui/CelestialBackdrop'
import { MainLayout } from '@/layouts/MainLayout'
import { AuthLayout } from '@/layouts/AuthLayout'
import LandingPage from '@/pages/LandingPage'
import LoginPage from '@/pages/auth/LoginPage'
import RegisterPage from '@/pages/auth/RegisterPage'
import ForgotPasswordPage from '@/pages/auth/ForgotPasswordPage'

/**
 * Route table. Landing + the auth flow (Login / Register / Forgot
 * Password) are real; everything else is scaffolded as a placeholder
 * so the app stays fully navigable while each remaining page is built
 * out, one at a time. Replace each placeholder import as its page
 * is delivered.
 *
 * Two layouts: MainLayout (floating navbar + footer) wraps marketing
 * and app pages; AuthLayout (split form / brand panel, no navbar or
 * footer) wraps the auth flow, which needs a quieter, focused frame.
 */
function ComingSoon({ title }: { title: string }) {
  return (
    <div className="relative z-10 min-h-[70vh] flex flex-col items-center justify-center text-center px-6 pt-32">
      <h1 className="font-display text-3xl font-semibold text-on-surface mb-3">{title}</h1>
      <p className="text-on-surface-variant max-w-md">
        This page hasn't been built yet — it's next up in the SkillSync build queue.
      </p>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <CelestialBackdrop />
      <Routes>
        <Route path="/" element={<MainLayout><LandingPage /></MainLayout>} />
        <Route path="/login" element={<AuthLayout><LoginPage /></AuthLayout>} />
        <Route path="/register" element={<AuthLayout><RegisterPage /></AuthLayout>} />
        <Route path="/forgot-password" element={<AuthLayout><ForgotPasswordPage /></AuthLayout>} />
        <Route path="/dashboard" element={<MainLayout><ComingSoon title="Dashboard" /></MainLayout>} />
        <Route path="/profile" element={<MainLayout><ComingSoon title="Profile" /></MainLayout>} />
        <Route path="/profile/edit" element={<MainLayout><ComingSoon title="Edit profile" /></MainLayout>} />
        <Route path="/explore" element={<MainLayout><ComingSoon title="Skill explorer" /></MainLayout>} />
        <Route path="/skills/:id" element={<MainLayout><ComingSoon title="Skill details" /></MainLayout>} />
        <Route path="/matches" element={<MainLayout><ComingSoon title="Matches" /></MainLayout>} />
        <Route path="/chat" element={<MainLayout><ComingSoon title="Chat" /></MainLayout>} />
        <Route path="/sessions/new" element={<MainLayout><ComingSoon title="Schedule a session" /></MainLayout>} />
        <Route path="/calendar" element={<MainLayout><ComingSoon title="Calendar" /></MainLayout>} />
        <Route path="/reviews" element={<MainLayout><ComingSoon title="Reviews" /></MainLayout>} />
        <Route path="/achievements" element={<MainLayout><ComingSoon title="Achievements" /></MainLayout>} />
        <Route path="/notifications" element={<MainLayout><ComingSoon title="Notifications" /></MainLayout>} />
        <Route path="/settings" element={<MainLayout><ComingSoon title="Settings" /></MainLayout>} />
        <Route path="/admin" element={<MainLayout><ComingSoon title="Admin dashboard" /></MainLayout>} />
        <Route path="*" element={<MainLayout><ComingSoon title="404 — Lost in space" /></MainLayout>} />
      </Routes>
    </BrowserRouter>
  )
}
